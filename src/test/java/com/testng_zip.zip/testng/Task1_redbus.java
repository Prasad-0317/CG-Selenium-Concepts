package com.testng;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import java.awt.AWTException;
import java.awt.Robot;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class Task1_redbus {
	WebDriver driver;
	int count = 0;
	
	 @BeforeTest
	  public void beforeTest() throws AWTException, InterruptedException {
		  driver = new EdgeDriver();
		  driver.manage().window().maximize();
		  driver.get("https://www.redbus.in/");
		  Robot robot = new Robot();
		  Thread.sleep(2000);
		  robot.mouseWheel(9);
	  }
	
  @Test
  public void testOffers() throws InterruptedException {
	  while(count<3) {
		  int current = count+1;
		  String xpath = "//div[@class = 'carousel___cd257e undefined']/div["+current+"]";
 		 Thread.sleep(2000);
		  driver.findElement(By.xpath(xpath)).click();
		  Thread.sleep(2000);
		  System.out.println(driver.getCurrentUrl());
		  count++;
		  driver.navigate().back(); 
	  }
	  
	  
	  
  }
 

  @AfterTest
  public void afterTest() {
  }

}
